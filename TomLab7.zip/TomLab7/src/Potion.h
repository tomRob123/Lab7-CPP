/*
 * Potion.h
 *
 *  Created on: Jan 16, 2020
 *      Author: ise
 */

#ifndef POTION_H_
#define POTION_H_

#include "Creature.h"

class Potion
{
public:
	Potion(){};
	virtual void drink(Creature& c) =0;
	virtual ~Potion(){};
};

#endif /* POTION_H_ */
