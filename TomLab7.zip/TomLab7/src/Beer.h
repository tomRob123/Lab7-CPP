/*
 * Beer.h
 *
 *  Created on: Jan 16, 2020
 *      Author: ise
 */

#ifndef BEER_H_
#define BEER_H_

#include "Potion.h"
class Beer : public Potion
{
public:
	Beer(){};
	virtual void drink(Creature& c) {c.drinkBeer();};
	virtual ~Beer() {};

};

#endif /* BEER_H_ */
