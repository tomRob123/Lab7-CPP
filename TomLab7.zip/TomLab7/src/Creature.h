/*
 * Creature.h
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#ifndef CREATURE_H_
#define CREATURE_H_
#include <iostream>
#include <cstring>

class Creature {
private:
	static const int MAX_HEALTH = 100;

protected:
	int health_stat;

public:
	Creature();
	int getHealthStat(){return health_stat;};
	void hurtHealth(int amount);
	void gainHealth(int amount);
	virtual std::string getType()=0;
	virtual void fight(Creature& c)=0;
	virtual ~Creature() {};

	// lab7

	virtual void drinkPoison()=0;
	virtual void drinkHealth()=0;
	virtual void drinkBeer()=0;
};



#endif /* CREATURE_H_ */
