/*
 * Wolf.cpp
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#include "Wolf.h"

void Wolf::fight(Creature& c)
{
if (c.getHealthStat() > 0 && this->getHealthStat()> 0)
	{
	if (c.getType() == "Penguin")
		{
		std::cout << this->getType() << " fought " << c.getType() << " - " << "Penguin has won" << std::endl;
		c.gainHealth(20);
		this->hurtHealth(50);
		return;
		}
	if (c.getType() == "Troll")
		{
		std::cout << this->getType() << " fought " << c.getType() << " - " << "Wolf has won" << std::endl;
		this->gainHealth(20);
		c.hurtHealth(50);
		return;
		}
	std::cout << "Two Wolves met - no fight" << std::endl;
	}
}
void Wolf::drinkPoison()
{
	this->hurtHealth(5);
}
void Wolf::drinkHealth()
{
	this->gainHealth(10);
}
void Wolf::drinkBeer()
{
	this->hurtHealth(5);
}
