/*
 * Creature.cpp
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#include "Creature.h"

Creature::Creature(): health_stat(MAX_HEALTH) {}

void Creature::hurtHealth(int amount)
{
if (this->health_stat - amount <= 0)
	{
	std::cout << this->getType() << " I have died!" << std::endl;
	return;
	}
std::cout << this->getType() << ": hurt for "<< amount << "points" << std::endl;

this->health_stat-=amount;
}
void Creature::gainHealth(int amount)
{
	if ((this->health_stat)+amount <= MAX_HEALTH)
	{
		std::cout << this->getType() << ": gained "<< amount <<  "points" << std::endl;
		this->health_stat+=amount;
	}
}
