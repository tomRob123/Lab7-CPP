/*
 * Penguin.cpp
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#include "Penguin.h"

void Penguin::fight(Creature& c)
{

	if (c.getHealthStat() > 0 && this->getHealthStat( )> 0)
		{
		if (c.getType() == "Troll")
			{
			std::cout << this->getType() << " fought " << c.getType() << " - " << "Troll has won" << std::endl;
			c.gainHealth(20);
			this->hurtHealth(50);
			return;
			}
		if (c.getType() == "Wolf")
			{
			std::cout << this->getType() << " fought " << c.getType() << " - " << "Penguin has won" << std::endl;
			this->gainHealth(20);
			c.hurtHealth(50);
			return;
			}
		std::cout << "Two Penguins met - no fight" << std::endl;
		}
}
void Penguin::drinkPoison()
{
	this->hurtHealth(10);
}
void Penguin::drinkHealth()
{
	this->gainHealth(5);
}
void Penguin::drinkBeer()
{
	this->gainHealth(5);
}

