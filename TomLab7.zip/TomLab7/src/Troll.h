/*
 * Troll.h
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#ifndef TROLL_H_
#define TROLL_H_

#include "Creature.h"

class Troll: public Creature {
public:
	Troll() {};
	virtual std::string getType() {return "Troll";};
	virtual void fight(Creature& c);
	virtual ~Troll() {};

	//lab7

	virtual void drinkPoison();
	virtual void drinkHealth();
	virtual void drinkBeer();
};

#endif /* TROLL_H_ */
