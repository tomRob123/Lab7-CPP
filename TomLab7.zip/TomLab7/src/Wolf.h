/*
 * Wolf.h
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#ifndef WOLF_H_
#define WOLF_H_

#include "Creature.h"

class Wolf: public Creature {
private:
	int mp;
public:
	Wolf() {};
	virtual std::string getType() {return "Wolf";};
	virtual void fight(Creature& c);
	virtual ~Wolf() {};

	//lab7

	virtual void drinkPoison();
	virtual void drinkHealth();
	virtual void drinkBeer();
};

#endif /* WOLF_H_ */
