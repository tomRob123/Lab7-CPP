/*
 * Penguin.h
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#ifndef PENGUIN_H_
#define PENGUIN_H_

#include "Creature.h"

class Penguin: public Creature {
public:
	Penguin() {};
	virtual std::string getType() {return "Penguin";};
	virtual void fight(Creature& c);
	virtual ~Penguin() {};

	//lab7

	virtual void drinkPoison();
	virtual void drinkHealth();
	virtual void drinkBeer();
};

#endif /* PENGUIN_H_ */
