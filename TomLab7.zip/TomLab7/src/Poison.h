/*
 * Poison.h
 *
 *  Created on: Jan 16, 2020
 *      Author: ise
 */

#ifndef POISON_H_
#define POISON_H_

#include "Potion.h"

class Poison : public Potion
{
public:
	Poison(){};
	virtual void drink(Creature& c) {c.drinkPoison();};
	virtual ~Poison() {};

};


#endif /* POISON_H_ */
