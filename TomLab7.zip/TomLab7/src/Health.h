/*
 * Health.h
 *
 *  Created on: Jan 16, 2020
 *      Author: ise
 */

#ifndef HEALTH_H_
#define HEALTH_H_

#include "Potion.h"

class Health : public Potion
{
public:
	Health(){};
	virtual void drink(Creature& c) {c.drinkHealth();};
	virtual ~Health() {};

};

#endif /* HEALTH_H_ */
