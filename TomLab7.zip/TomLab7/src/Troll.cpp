/*
 * Troll.cpp
 *
 *  Created on: Jan 9, 2020
 *      Author: ise
 */

#include "Troll.h"

void Troll::fight(Creature& c)
{
	if (c.getHealthStat() > 0 && this->getHealthStat()> 0)
		{
		if (c.getType() == "Wolf")
			{
			std::cout << this->getType() << " fought " << c.getType() << " - " << "Wolf has won" << std::endl;
			c.gainHealth(20);
			this->hurtHealth(50);
			return;
			}
		if (c.getType() == "Penguin")
			{
			std::cout << this->getType() << " fought " << c.getType() << " - " << "Troll has won" << std::endl;
			this->gainHealth(20);
			c.hurtHealth(50);
			return;
			}
		std::cout << "Two Trolls met - no fight" << std::endl;
		}
}

void Troll::drinkPoison()
{
	this->gainHealth(5);
}
void Troll::drinkHealth()
{
	this->hurtHealth(10);
}
void Troll::drinkBeer()
{
	this->gainHealth(5);
}
