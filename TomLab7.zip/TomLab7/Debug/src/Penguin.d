src/Penguin.d: ../src/Penguin.cpp ../src/Penguin.h ../src/Creature.h

../src/Penguin.h:

../src/Creature.h:
