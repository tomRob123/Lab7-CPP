src/Troll.d: ../src/Troll.cpp ../src/Troll.h ../src/Creature.h

../src/Troll.h:

../src/Creature.h:
