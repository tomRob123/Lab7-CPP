src/main.d: ../src/main.cpp ../src/Creature.h ../src/Wolf.h \
 ../src/Troll.h ../src/Penguin.h ../src/Potion.h ../src/Health.h \
 ../src/Poison.h ../src/Beer.h

../src/Creature.h:

../src/Wolf.h:

../src/Troll.h:

../src/Penguin.h:

../src/Potion.h:

../src/Health.h:

../src/Poison.h:

../src/Beer.h:
