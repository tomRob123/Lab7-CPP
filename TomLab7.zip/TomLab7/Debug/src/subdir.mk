################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../src/Creature.cpp \
../src/Penguin.cpp \
../src/Troll.cpp \
../src/Wolf.cpp \
../src/main.cpp 

OBJS += \
./src/Creature.o \
./src/Penguin.o \
./src/Troll.o \
./src/Wolf.o \
./src/main.o 

CPP_DEPS += \
./src/Creature.d \
./src/Penguin.d \
./src/Troll.d \
./src/Wolf.d \
./src/main.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C++ Compiler'
	g++ -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


