src/Wolf.d: ../src/Wolf.cpp ../src/Wolf.h ../src/Creature.h

../src/Wolf.h:

../src/Creature.h:
